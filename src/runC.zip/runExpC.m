close all; clear; clc;

run c1;
disp('C1 finished!');
run c2;
disp('C2 finished!');
run c3;
disp('C3 finished!');
run c4;
disp('C4 finished!');
disp('All finished! Oh yeah!!!');